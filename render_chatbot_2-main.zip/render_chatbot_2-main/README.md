# Install
run the following for dependencies
`pip install flask flask-cors sentence-transformers numpy requests
`

# RUN
`python3 app.py`
